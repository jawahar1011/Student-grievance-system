from django.apps import AppConfig


class ClientSiteConfig(AppConfig):
    name = 'Remote_User'
