from django.apps import AppConfig


class ResearchSiteConfig(AppConfig):
    name = 'Tweet_Server'
